
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, MeshDistortMaterial, Sphere, Torus, Cylinder, Stars, Environment, Box, Octahedron, SpotLight } from '@react-three/drei';
import * as THREE from 'three';

// Extend JSX.IntrinsicElements to include React Three Fiber elements
declare global {
  namespace JSX {
    interface IntrinsicElements {
      ambientLight: any;
      pointLight: any;
      spotLight: any;
      group: any;
      meshStandardMaterial: any;
    }
  }
}

declare module 'react' {
  namespace JSX {
    interface IntrinsicElements {
      ambientLight: any;
      pointLight: any;
      spotLight: any;
      group: any;
      meshStandardMaterial: any;
    }
  }
}

const InkBlob = ({ position, color, scale = 1, speed = 1 }: { position: [number, number, number]; color: string; scale?: number, speed?: number }) => {
  const ref = useRef<THREE.Mesh>(null);
  const initialPos = useRef(new THREE.Vector3(...position));
  
  useFrame((state) => {
    if (ref.current) {
      const t = state.clock.getElapsedTime();
      const { x, y } = state.pointer; // Mouse position (-1 to 1)

      // Organic floating motion mixed with mouse influence
      // Calculate target position (initial + mouse offset)
      const moveAmp = 1.5; // How much the mouse affects position
      const targetX = initialPos.current.x + (x * moveAmp);
      const targetY = initialPos.current.y + (y * moveAmp) + Math.sin(t * speed + position[0]) * 0.3;

      // Smoothly interpolate (Lerp) current position to target
      ref.current.position.x = THREE.MathUtils.lerp(ref.current.position.x, targetX, 0.08);
      ref.current.position.y = THREE.MathUtils.lerp(ref.current.position.y, targetY, 0.08);
      
      // Dynamic rotation based on mouse
      ref.current.rotation.x = THREE.MathUtils.lerp(ref.current.rotation.x, t * 0.2 + y * 0.5, 0.1);
      ref.current.rotation.z = THREE.MathUtils.lerp(ref.current.rotation.z, t * 0.1 - x * 0.5, 0.1);
    }
  });

  return (
    <Sphere ref={ref} args={[1, 64, 64]} position={position} scale={scale}>
      <MeshDistortMaterial
        color={color}
        envMapIntensity={3} // High intensity for vibrant reflections
        clearcoat={1}
        clearcoatRoughness={0}
        metalness={0.1}
        roughness={0}
        distort={0.6}
        speed={speed}
      />
    </Sphere>
  );
};

const FloatingRing = () => {
  const ref = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (ref.current) {
       const t = state.clock.getElapsedTime();
       const { x, y } = state.pointer;

       // Rotate based on time and mouse tilt
       const targetRotX = (Math.PI / 2) + Math.sin(t * 0.3) * 0.2 - (y * 0.2);
       const targetRotY = (t * 0.05) + (x * 0.2);

       ref.current.rotation.x = THREE.MathUtils.lerp(ref.current.rotation.x, targetRotX, 0.1);
       ref.current.rotation.y = THREE.MathUtils.lerp(ref.current.rotation.y, targetRotY, 0.1);
    }
  });

  return (
    <Torus ref={ref} args={[3.5, 0.02, 16, 100]} rotation={[Math.PI / 2, 0, 0]}>
      <meshStandardMaterial color="#C5A059" emissive="#C5A059" emissiveIntensity={0.5} transparent opacity={0.4} />
    </Torus>
  );
}

// Group that rotates slightly based on mouse position
const MouseParallaxGroup = ({ children }: { children: React.ReactNode }) => {
  const group = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (group.current) {
      const { x, y } = state.pointer;
      // Tilt the entire group against the mouse movement for parallax depth
      group.current.rotation.x = THREE.MathUtils.lerp(group.current.rotation.x, -y * 0.1, 0.1);
      group.current.rotation.y = THREE.MathUtils.lerp(group.current.rotation.y, x * 0.1, 0.1);
    }
  });
  return <group ref={group}>{children}</group>;
}

export const HeroScene: React.FC = () => {
  return (
    <div className="absolute inset-0 z-0 opacity-100">
      {/* eventSource={document.body} allows mouse control even if overlay covers canvas */}
      <Canvas eventSource={document.body} eventPrefix="client" camera={{ position: [0, 0, 6], fov: 45 }}>
        <ambientLight intensity={1.2} />
        <pointLight position={[10, 10, 10]} intensity={2} color="#fff" />
        {/* Colored light for extra vibrancy */}
        <pointLight position={[-10, -5, 5]} intensity={1} color="#a78bfa" />
        
        <MouseParallaxGroup>
          {/* Main Ink Blob - Vibrant Violet/Purple */}
          <InkBlob position={[0, 0, 0]} color="#8b5cf6" scale={1.3} speed={1.5} />
          
          <FloatingRing />
          
          {/* Accent Blob - Hot Pink */}
          <InkBlob position={[-3, 1, -2]} color="#ec4899" scale={0.7} speed={2} />
          
          {/* Accent Blob - Cyan/Blue */}
          <InkBlob position={[3, -1, -3]} color="#06b6d4" scale={0.9} speed={1.8} />

          {/* Accent Blob - Amber/Gold */}
          <InkBlob position={[0, 2.5, -4]} color="#fbbf24" scale={0.6} speed={2.2} />
        </MouseParallaxGroup>

        <Environment preset="city" />
      </Canvas>
    </div>
  );
};

export const QuantumComputerScene: React.FC = () => {
  return (
    <div className="w-full h-full absolute inset-0">
      <Canvas eventSource={document.body} eventPrefix="client" camera={{ position: [0, 0, 5], fov: 40 }}>
        <ambientLight intensity={1} />
        <spotLight position={[5, 5, 5]} angle={0.3} penumbra={1} intensity={2} color="#C5A059" />
        <pointLight position={[-5, -5, -5]} intensity={0.5} />
        <Environment preset="city" />
        
        <MouseParallaxGroup>
          <Float rotationIntensity={0.2} floatIntensity={0.2} speed={1}>
            <group rotation={[0, Math.PI / 4, 0]} position={[0, -0.5, 0]}>
              {/* The "Monument to Knowledge" - Stylized stacked books / pillar */}
              
              {/* Base */}
              <Box args={[2, 0.2, 2]} position={[0, -1, 0]}>
                <meshStandardMaterial color="#292524" metalness={0.5} roughness={0.5} />
              </Box>

              {/* Stack Element 1 */}
              <Box args={[1.6, 0.3, 1.6]} position={[0, -0.7, 0]}>
                <meshStandardMaterial color="#F5F5F4" metalness={0.1} roughness={0.8} />
              </Box>
              <Box args={[1.65, 0.05, 1.65]} position={[0, -0.54, 0]}>
                <meshStandardMaterial color="#C5A059" metalness={0.8} roughness={0.2} />
              </Box>

              {/* Stack Element 2 */}
              <Box args={[1.3, 0.3, 1.3]} position={[0, -0.3, 0]}>
                <meshStandardMaterial color="#44403c" metalness={0.2} roughness={0.7} />
              </Box>
              <Box args={[1.35, 0.05, 1.35]} position={[0, -0.14, 0]}>
                <meshStandardMaterial color="#C5A059" metalness={0.8} roughness={0.2} />
              </Box>

              {/* Stack Element 3 */}
              <Box args={[1, 0.3, 1]} position={[0, 0.1, 0]}>
                <meshStandardMaterial color="#F5F5F4" metalness={0.1} roughness={0.8} />
              </Box>
              
              {/* Top "Nib" Structure */}
              <Cylinder args={[0, 0.5, 1.2, 4]} position={[0, 0.9, 0]} rotation={[0, Math.PI/4, 0]}>
                  <meshStandardMaterial color="#C5A059" metalness={1} roughness={0.1} />
              </Cylinder>

              {/* Floating particles around it */}
              <Float speed={4} rotationIntensity={1} floatIntensity={2}>
                  <Octahedron args={[0.1]} position={[1, 1, 1]}>
                      <meshStandardMaterial color="#C5A059" metalness={1} roughness={0} />
                  </Octahedron>
                  <Octahedron args={[0.08]} position={[-1, 0.5, 1]}>
                      <meshStandardMaterial color="#C5A059" metalness={1} roughness={0} />
                  </Octahedron>
                  <Octahedron args={[0.12]} position={[0, 2, -0.5]}>
                      <meshStandardMaterial color="#292524" metalness={1} roughness={0} />
                  </Octahedron>
              </Float>

            </group>
          </Float>
        </MouseParallaxGroup>
      </Canvas>
    </div>
  );
}
