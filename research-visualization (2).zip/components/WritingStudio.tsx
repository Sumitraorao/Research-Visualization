
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useEffect, useRef } from 'react';
import { 
  ArrowLeft, Wand2, BarChart2, CheckCircle, 
  RefreshCw, Sparkles, Type, AlignLeft, 
  Share2, Save, MoreHorizontal, Code,
  MessageSquare, Send, X, Calendar
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface WritingStudioProps {
  onBack: () => void;
  user: any; // Passed from App.tsx
}

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  isAction?: boolean;
}

const ChatBot = ({ isOpen, onClose, userName }: { isOpen: boolean; onClose: () => void; userName?: string }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: `Hi ${userName || 'there'}! I'm Sumit's AI Assistant. I can help you with project inquiries or book a demo call.`,
      sender: 'bot',
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Initial Greeting if user logs in
  useEffect(() => {
     if (userName) {
         setMessages(prev => [
             ...prev, 
             { id: 'login-greet', text: `Welcome back, ${userName}! Ready to see what we can build?`, sender: 'bot', timestamp: new Date() }
         ]);
     }
  }, [userName]);

  const handleSend = (textOverride?: string) => {
    const textToSend = textOverride || inputText;
    if (!textToSend.trim()) return;

    const newUserMsg: Message = {
      id: Date.now().toString(),
      text: textToSend,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newUserMsg]);
    setInputText("");
    setIsTyping(true);

    // Simulate AI processing and response
    setTimeout(() => {
      let botResponseText = "Thanks for your message! Sumit will get back to you shortly.";
      const lowerInput = textToSend.toLowerCase();

      // Simple keyword matching for demo purposes
      if (lowerInput.includes('hire') || lowerInput.includes('project') || lowerInput.includes('work')) {
        botResponseText = "I'd love to hear about your project! Please send a brief brief to hello@sumitrao.dev, or let me know your budget range here.";
      } else if (lowerInput.includes('stack') || lowerInput.includes('tech') || lowerInput.includes('react')) {
        botResponseText = "This portfolio is built with React 19, TypeScript, Tailwind CSS, and React Three Fiber for the 3D elements. I also specialize in Next.js and Node.js backends.";
      } else if (lowerInput.includes('hello') || lowerInput.includes('hi')) {
        botResponseText = "Hello! How can I help you build your next digital product?";
      } else if (lowerInput.includes('book') || lowerInput.includes('demo') || lowerInput.includes('call')) {
        botResponseText = "I can definitely help with that. Please select a time slot below:";
        // Trigger simulated booking action
        setTimeout(() => {
            setMessages(prev => [...prev, {
                id: Date.now().toString() + 'action',
                text: "Available Slots:",
                sender: 'bot',
                timestamp: new Date(),
                isAction: true
            }]);
        }, 500);
      } else if (lowerInput.includes('price') || lowerInput.includes('cost') || lowerInput.includes('rate')) {
        botResponseText = "My rates vary depending on project complexity. For a standard consultation, I start at $150/hr. Shall I schedule a call?";
      }

      const newBotMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: botResponseText,
        sender: 'bot',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, newBotMsg]);
      setIsTyping(false);
    }, 1500);
  };

  const handleBookSlot = (slot: string) => {
      setMessages(prev => [...prev, { id: Date.now().toString(), text: `Booked for ${slot}`, sender: 'user', timestamp: new Date() }]);
      setIsTyping(true);
      setTimeout(() => {
          setMessages(prev => [...prev, {
              id: Date.now().toString(), 
              text: `Perfect! I've sent a calendar invite to your email. Talk soon!`, 
              sender: 'bot', 
              timestamp: new Date() 
          }]);
          setIsTyping(false);
      }, 1000);
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
           initial={{ opacity: 0, y: 20, scale: 0.95 }}
           animate={{ opacity: 1, y: 0, scale: 1 }}
           exit={{ opacity: 0, y: 20, scale: 0.95 }}
           className="fixed bottom-24 right-6 w-80 md:w-96 bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden z-50 flex flex-col font-sans"
           style={{ height: '500px', maxHeight: '70vh' }}
        >
           {/* Header */}
           <div className="bg-stone-900 p-4 text-white flex justify-between items-center shadow-md">
              <div className="flex items-center gap-3">
                 <div className="w-10 h-10 rounded-full bg-nobel-gold flex items-center justify-center font-serif font-bold text-stone-900 text-lg">S</div>
                 <div>
                    <div className="font-bold text-sm">Sumit Rao</div>
                    <div className="text-[10px] text-stone-400 flex items-center gap-1.5">
                        <span className="relative flex h-2 w-2">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                        </span>
                        Online Assistant
                    </div>
                 </div>
              </div>
              <button onClick={onClose} className="text-stone-400 hover:text-white transition-colors">
                  <X size={20} />
              </button>
           </div>

           {/* Messages */}
           <div className="flex-1 overflow-y-auto p-4 bg-[#F9F8F4] space-y-4">
              <div className="text-center text-[10px] text-stone-400 font-bold tracking-widest uppercase mb-4">Today</div>
              {messages.map(m => (
                 <div key={m.id} className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}>
                    <div className={`max-w-[85%] p-3.5 rounded-2xl text-sm leading-relaxed shadow-sm ${m.sender === 'user' ? 'bg-stone-900 text-white rounded-br-none' : 'bg-white text-stone-800 border border-stone-100 rounded-bl-none'}`}>
                       {m.text}
                    </div>
                    
                    {/* Interactive Elements for Bot */}
                    {m.isAction && (
                        <div className="mt-2 flex flex-col gap-2 w-full max-w-[85%]">
                            {['Tue, 10:00 AM', 'Wed, 2:00 PM', 'Thu, 11:30 AM'].map(slot => (
                                <button 
                                    key={slot}
                                    onClick={() => handleBookSlot(slot)}
                                    className="flex items-center gap-2 px-4 py-2 bg-white border border-nobel-gold/50 text-stone-800 rounded-lg text-xs font-medium hover:bg-nobel-gold hover:text-white transition-colors shadow-sm"
                                >
                                    <Calendar size={14} /> {slot}
                                </button>
                            ))}
                        </div>
                    )}
                 </div>
              ))}
              
              {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-white p-3 rounded-2xl rounded-bl-none border border-stone-100 shadow-sm flex gap-1 items-center h-10">
                        <span className="w-1.5 h-1.5 bg-stone-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></span>
                        <span className="w-1.5 h-1.5 bg-stone-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></span>
                        <span className="w-1.5 h-1.5 bg-stone-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></span>
                    </div>
                  </div>
              )}
              <div ref={messagesEndRef} />
           </div>

           {/* Input */}
           <div className="p-3 bg-white border-t border-stone-100">
              <form 
                onSubmit={(e) => { e.preventDefault(); handleSend(); }}
                className="flex gap-2 items-center"
              >
                 <input 
                    className="flex-1 bg-stone-50 rounded-full px-4 py-3 text-sm text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-nobel-gold focus:bg-white transition-all border border-transparent focus:border-stone-200"
                    placeholder="Type a message..."
                    value={inputText}
                    onChange={e => setInputText(e.target.value)}
                 />
                 <button 
                    type="submit" 
                    disabled={!inputText.trim()}
                    className="p-3 bg-nobel-gold text-stone-900 rounded-full hover:bg-[#b08d4b] transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
                 >
                    <Send size={18} />
                 </button>
              </form>
           </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export const WritingStudio: React.FC<WritingStudioProps> = ({ onBack, user }) => {
  const [content, setContent] = useState<string>("This is a live demo of a text editor I built using React and Framer Motion.\n\nIt features real-time analysis, state management, and a clean, distraction-free UI. Go ahead, type something...");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [tone, setTone] = useState<'Neutral' | 'Professional' | 'Casual'>('Neutral');
  const [clarityScore, setClarityScore] = useState(95);
  const [activeTab, setActiveTab] = useState<'stats' | 'json' | 'settings'>('stats');
  const [isChatOpen, setIsChatOpen] = useState(false);

  // Metrics
  const wordCount = content.split(/\s+/).filter(w => w.length > 0).length;
  const readTime = Math.ceil(wordCount / 200);

  // Simulation of AI processing
  const handleAiAction = (action: string) => {
    setIsAnalyzing(true);
    setTimeout(() => {
      setIsAnalyzing(false);
      if (action === 'code') {
        setContent(prev => prev + "\n\n// Here is a snippet generated by the action:\nconst hello = () => {\n  console.log('Hello World');\n};");
        setTone('Professional');
      } else if (action === 'expand') {
        setContent(prev => prev + "\n\nNotice how the UI responds instantly? I prioritize performance in all my builds.");
        setTone('Casual');
      }
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-[#F9F8F4] text-stone-800 flex flex-col animate-fade-in relative">
      
      <ChatBot isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} userName={user?.name} />
      
      {/* Floating Chat Launcher */}
      <button 
        onClick={() => setIsChatOpen(!isChatOpen)}
        className={`fixed bottom-8 right-6 w-14 h-14 rounded-full shadow-xl flex items-center justify-center transition-all duration-300 z-40 ${isChatOpen ? 'bg-stone-200 text-stone-600 rotate-90' : 'bg-stone-900 text-white hover:scale-110'}`}
      >
         {isChatOpen ? <X size={24}/> : <MessageSquare size={24} />}
      </button>

      {/* Top Navigation */}
      <nav className="h-16 border-b border-stone-200 bg-white/80 backdrop-blur flex items-center justify-between px-6 sticky top-0 z-20">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-stone-100 rounded-full transition-colors text-stone-500 hover:text-stone-900"
          >
            <ArrowLeft size={20} />
          </button>
          <div className="flex flex-col">
            <span className="font-serif font-bold text-lg leading-none text-stone-900">Live Project Demo</span>
            <span className="text-xs text-stone-400 font-medium uppercase tracking-wider mt-1">Sumit Rao Portfolio</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden md:flex items-center gap-4 mr-4 text-xs font-medium text-stone-500">
             <span className="flex items-center gap-1"><Code size={14} className="text-stone-400"/> React 19</span>
             <span>{wordCount} words</span>
          </div>
          
          {user ? (
              <div className="flex items-center gap-2 bg-stone-100 px-3 py-1.5 rounded-full border border-stone-200">
                  <img src={user.photo} className="w-5 h-5 rounded-full" alt="user" />
                  <span className="text-xs font-bold text-stone-600">Logged In</span>
              </div>
          ) : (
            <button 
                onClick={() => setIsChatOpen(true)}
                className="px-4 py-2 bg-stone-900 text-white rounded-full text-sm font-medium hover:bg-stone-800 transition-colors flex items-center gap-2 shadow-sm"
            >
                Contact Me
            </button>
          )}
        </div>
      </nav>

      <div className="flex-1 flex overflow-hidden">
        {/* Main Editor */}
        <div className="flex-1 overflow-y-auto relative">
           <div className="max-w-3xl mx-auto py-16 px-8 md:px-12">
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full h-[calc(100vh-200px)] bg-transparent resize-none border-none focus:ring-0 font-serif text-xl md:text-2xl leading-relaxed text-stone-800 placeholder-stone-300 outline-none selection:bg-nobel-gold/30 selection:text-stone-900"
                placeholder="Start typing..."
                spellCheck={false}
              />
           </div>
        </div>

        {/* Sidebar */}
        <div className="w-80 bg-white border-l border-stone-200 hidden md:flex flex-col z-10 shadow-sm">
           
           {/* Sidebar Tabs */}
           <div className="flex border-b border-stone-100">
              <button 
                onClick={() => setActiveTab('stats')}
                className={`flex-1 py-4 text-xs font-bold uppercase tracking-wider transition-colors border-b-2 ${activeTab === 'stats' ? 'border-nobel-gold text-stone-900' : 'border-transparent text-stone-400 hover:text-stone-600'}`}
              >
                Analysis
              </button>
              <button 
                onClick={() => setActiveTab('json')}
                className={`flex-1 py-4 text-xs font-bold uppercase tracking-wider transition-colors border-b-2 ${activeTab === 'json' ? 'border-nobel-gold text-stone-900' : 'border-transparent text-stone-400 hover:text-stone-600'}`}
              >
                Debug
              </button>
           </div>

           {/* Sidebar Content */}
           <div className="flex-1 p-6 overflow-y-auto">
              
              {/* Tab: Stats */}
              {activeTab === 'stats' && (
                <div className="space-y-8 animate-fade-in">
                   <div>
                      <h3 className="font-serif text-lg text-stone-900 mb-4 flex items-center gap-2">
                        <Sparkles size={18} className="text-nobel-gold"/> Demo Actions
                      </h3>
                      <div className="space-y-3">
                         <button 
                            disabled={isAnalyzing}
                            onClick={() => handleAiAction('code')}
                            className="w-full p-3 text-left border border-stone-200 rounded-lg hover:border-nobel-gold hover:bg-[#F9F8F4] transition-all group relative overflow-hidden"
                         >
                            <span className="block text-sm font-bold text-stone-700">Inject Code Block</span>
                            <span className="text-xs text-stone-400">Simulate adding complex data.</span>
                         </button>

                         <button 
                            disabled={isAnalyzing}
                            onClick={() => handleAiAction('expand')}
                            className="w-full p-3 text-left border border-stone-200 rounded-lg hover:border-nobel-gold hover:bg-[#F9F8F4] transition-all"
                         >
                            <span className="block text-sm font-bold text-stone-700">Performance Test</span>
                            <span className="text-xs text-stone-400">Test input lag responsiveness.</span>
                         </button>
                      </div>
                   </div>

                   <div>
                      <h3 className="font-serif text-lg text-stone-900 mb-4 flex items-center gap-2">
                        <AlignLeft size={18} className="text-stone-400"/> Real-time Metrics
                      </h3>
                      <div className="bg-[#F9F8F4] p-4 rounded-lg">
                         <div className="flex justify-between items-center mb-2">
                            <span className="text-sm font-medium text-stone-600">Structure Score</span>
                            <span className="text-lg font-bold text-green-600">{clarityScore}</span>
                         </div>
                         <div className="w-full bg-stone-200 h-1.5 rounded-full overflow-hidden">
                            <div 
                                className="h-full bg-stone-900 transition-all duration-1000" 
                                style={{width: `${clarityScore}%`}}
                            ></div>
                         </div>
                      </div>
                   </div>
                </div>
              )}

              {/* Tab: Debug */}
              {activeTab === 'json' && (
                  <div className="space-y-4 animate-fade-in font-mono text-xs text-stone-600">
                     <div className="p-4 bg-stone-100 rounded-lg overflow-hidden">
                        <div className="font-bold mb-2">State Snapshot</div>
                        <pre className="whitespace-pre-wrap break-all">
                            {JSON.stringify({ 
                                words: wordCount, 
                                tone: tone, 
                                analyzing: isAnalyzing,
                                user: user ? user.name : 'Guest'
                            }, null, 2)}
                        </pre>
                     </div>
                     <p className="text-stone-400 italic">This demonstrates how I handle state in complex applications.</p>
                  </div>
              )}
           </div>
        </div>
      </div>
    </div>
  );
};
