
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PenTool, CheckCircle, BarChart2, Lightbulb, Code, Layers, Figma, Terminal, Cpu, Zap, Globe, Box, LayoutTemplate } from 'lucide-react';

// --- SKILL MATRIX (Formerly Surface Code) ---
export const SurfaceCodeDiagram: React.FC = () => {
  // Grid of "Skills"
  const [selectedWords, setSelectedWords] = useState<number[]>([]);
  
  const toggleWord = (id: number) => {
    setSelectedWords(prev => prev.includes(id) ? prev.filter(e => e !== id) : [...prev, id]);
  };

  const proficiency = Math.min(100, selectedWords.length * 20);

  return (
    <div className="flex flex-col items-center p-8 bg-white rounded-xl shadow-sm border border-stone-200 my-8">
      <h3 className="font-serif text-xl mb-4 text-stone-800">Skill Matrix</h3>
      <p className="text-sm text-stone-500 mb-6 text-center max-w-md">
        Click to explore my stack. <span className="text-nobel-gold font-bold">Interactive</span>
      </p>
      
      <div className="relative w-72 h-72 bg-[#F5F4F0] rounded-lg border border-stone-200 p-4 flex flex-wrap justify-between content-between relative">
         {/* Grid Lines */}
         <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-10">
            <div className="w-full h-[1px] bg-stone-400 absolute top-1/3"></div>
            <div className="w-full h-[1px] bg-stone-400 absolute top-2/3"></div>
            <div className="h-full w-[1px] bg-stone-400 absolute left-1/3"></div>
            <div className="h-full w-[1px] bg-stone-400 absolute left-2/3"></div>
         </div>

         {/* Skills / Nodes */}
         {[
             {id: 0, x: '20%', y: '20%', label: 'React'}, 
             {id: 1, x: '50%', y: '20%', label: 'TS'},
             {id: 2, x: '80%', y: '20%', label: 'Node'},
             {id: 3, x: '20%', y: '50%', label: 'Figma'}, 
             {id: 4, x: '50%', y: '50%', label: 'UI/UX'}, 
             {id: 5, x: '80%', y: '50%', label: 'Three'},
             {id: 6, x: '20%', y: '80%', label: 'Next'}, 
             {id: 7, x: '50%', y: '80%', label: 'SQL'},
             {id: 8, x: '80%', y: '80%', label: 'AWS'},
         ].map(q => (
             <button
                key={`word-${q.id}`}
                onClick={() => toggleWord(q.id)}
                className={`absolute w-14 h-14 -ml-7 -mt-7 rounded-full border flex items-center justify-center text-[10px] font-medium tracking-wide transition-all duration-300 z-10 ${selectedWords.includes(q.id) ? 'bg-stone-900 border-stone-900 text-white scale-110 shadow-lg' : 'bg-white border-stone-300 text-stone-500 hover:border-stone-500 hover:text-stone-800'}`}
                style={{ left: q.x, top: q.y }}
             >
                {q.label}
             </button>
         ))}
      </div>

      <div className="mt-6 w-full px-8">
          <div className="flex justify-between text-xs font-mono text-stone-500 mb-2">
            <span>PROFICIENCY DISPLAY</span>
            <span>{proficiency > 0 ? 'ACTIVE' : 'IDLE'}</span>
          </div>
          <div className="h-1 bg-stone-200 rounded-full overflow-hidden">
            <div 
                className="h-full bg-stone-900 transition-all duration-500" 
                style={{ width: `${proficiency}%` }}
            ></div>
          </div>
      </div>
    </div>
  );
};

// --- ANIMATION COMPONENTS FOR WORKFLOW ---

const IdeaAnimation = () => (
  <div className="w-full h-full relative flex items-center justify-center overflow-hidden bg-stone-100 rounded-lg">
    {/* Chaos particles */}
    {[...Array(6)].map((_, i) => (
      <motion.div
        key={i}
        className="absolute w-2 h-2 rounded-full bg-stone-400"
        animate={{
          x: [Math.random() * 100 - 50, 0],
          y: [Math.random() * 100 - 50, 0],
          opacity: [0, 1, 0],
          scale: [0.5, 1.2, 0]
        }}
        transition={{ duration: 2, repeat: Infinity, delay: i * 0.2 }}
      />
    ))}
    {/* Synthesis */}
    <motion.div
      className="z-10 bg-nobel-gold text-stone-900 p-3 rounded-full shadow-lg"
      animate={{ scale: [0.8, 1.1, 0.8], boxShadow: ["0px 0px 0px rgba(197,160,89,0)", "0px 0px 20px rgba(197,160,89,0.5)", "0px 0px 0px rgba(197,160,89,0)"] }}
      transition={{ duration: 2, repeat: Infinity }}
    >
      <Lightbulb size={24} fill="currentColor" className="text-white" />
    </motion.div>
    <div className="absolute bottom-4 text-[10px] font-mono text-stone-500">SYNTHESIZING...</div>
  </div>
);

const DesignAnimation = () => (
  <div className="w-full h-full relative flex items-center justify-center bg-stone-100 rounded-lg overflow-hidden p-6">
    <div className="w-48 bg-white shadow-xl rounded-lg overflow-hidden border border-stone-200 flex flex-col">
       {/* Header */}
       <div className="h-8 bg-stone-100 border-b border-stone-200 flex items-center px-2 gap-1">
          <div className="w-2 h-2 rounded-full bg-red-300"></div>
          <div className="w-2 h-2 rounded-full bg-yellow-300"></div>
       </div>
       {/* Body Wireframe -> HiFi */}
       <div className="p-3 space-y-2 flex-1 relative">
          <motion.div 
            className="h-2 w-2/3 bg-stone-200 rounded"
            animate={{ backgroundColor: ["#e7e5e4", "#1c1917", "#e7e5e4"] }}
            transition={{ duration: 3, repeat: Infinity }}
          />
          <motion.div 
            className="h-16 w-full bg-stone-200 rounded"
            animate={{ backgroundColor: ["#e7e5e4", "#C5A059", "#e7e5e4"] }}
            transition={{ duration: 3, repeat: Infinity, delay: 0.2 }}
          />
          <div className="flex gap-2">
             <div className="h-8 w-1/2 bg-stone-200 rounded animate-pulse"></div>
             <div className="h-8 w-1/2 bg-stone-200 rounded animate-pulse"></div>
          </div>
          
          {/* Cursor Overlay */}
          <motion.div 
            className="absolute top-10 left-10 pointer-events-none"
            animate={{ x: [0, 30, 0], y: [0, 20, 0] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          >
             <svg width="15" height="15" viewBox="0 0 24 24" fill="black" className="drop-shadow-md"><path d="M0 0l6.5 18.5L10 12l8 8 1.5-1.5-8-8L19 6 0 0z"/></svg>
          </motion.div>
       </div>
    </div>
  </div>
);

const BuildAnimation = () => (
  <div className="w-full h-full relative flex flex-col items-center justify-center bg-stone-900 rounded-lg overflow-hidden p-6 font-mono text-xs">
    <div className="w-full max-w-[200px]">
        <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }} 
            className="text-pink-400 mb-1"
        >
            const Experience = () =&gt; &#123;
        </motion.div>
        <motion.div 
            initial={{ width: 0 }}
            animate={{ width: "100%" }}
            transition={{ duration: 1.5, repeat: Infinity, repeatDelay: 1 }}
            className="h-4 bg-stone-800 rounded mb-1 overflow-hidden whitespace-nowrap text-blue-300 px-2 flex items-center"
        >
            return &lt;Interactive /&gt;
        </motion.div>
        <motion.div 
            initial={{ width: 0 }}
            animate={{ width: "80%" }}
            transition={{ duration: 1.5, delay: 0.2, repeat: Infinity, repeatDelay: 1 }}
            className="h-4 bg-stone-800 rounded mb-1 overflow-hidden whitespace-nowrap text-green-300 px-2 flex items-center"
        >
            isOptimized={true}
        </motion.div>
        <div className="text-pink-400">&#125;;</div>
    </div>
    
    <motion.div 
        className="mt-4 flex gap-1"
        animate={{ opacity: [0, 1, 0] }}
        transition={{ duration: 1, repeat: Infinity }}
    >
        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
        <span className="text-green-500 text-[10px]">Compiling...</span>
    </motion.div>
  </div>
);

const ShipAnimation = () => (
  <div className="w-full h-full relative flex items-center justify-center bg-stone-100 rounded-lg overflow-hidden">
     {/* Globe / Network */}
     <div className="absolute inset-0 flex items-center justify-center opacity-20">
         <Globe size={120} className="text-stone-900" strokeWidth={0.5} />
     </div>
     
     {/* Rocket / Success */}
     <motion.div 
        className="relative z-10 flex flex-col items-center"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
     >
        <motion.div 
            animate={{ scale: [1, 1.2, 1], rotate: [0, 5, -5, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center shadow-lg shadow-green-200 mb-2"
        >
            <Zap size={32} className="text-white fill-white" />
        </motion.div>
        <div className="bg-white border border-stone-200 px-3 py-1 rounded-full text-[10px] font-bold tracking-widest uppercase shadow-sm flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
            Deployed
        </div>
     </motion.div>
     
     {/* Particles */}
     {[...Array(8)].map((_, i) => (
         <motion.div
            key={i}
            className="absolute w-1 h-4 bg-stone-300 rounded-full"
            style={{ left: '50%', top: '50%' }}
            animate={{ 
                y: [0, (Math.random() - 0.5) * 200],
                x: [0, (Math.random() - 0.5) * 200],
                opacity: [1, 0],
                rotate: Math.random() * 360
            }}
            transition={{ duration: 1.5, repeat: Infinity, delay: Math.random() }}
         />
     ))}
  </div>
);


// --- WORKFLOW DIAGRAM (Formerly Transformer) ---
export const TransformerDecoderDiagram: React.FC = () => {
  const [step, setStep] = useState(0);
  const [isHovered, setIsHovered] = useState(false);

  // Auto-play unless hovered
  useEffect(() => {
    if (isHovered) return;
    const interval = setInterval(() => {
        setStep(s => (s + 1) % 4);
    }, 4000); // Slower interval to read content
    return () => clearInterval(interval);
  }, [isHovered]);

  const stages = [
      {
          id: 0,
          label: "Discovery",
          icon: Lightbulb,
          color: "text-nobel-gold",
          title: "Idea Synthesis",
          desc: "Converting abstract problems into concrete requirements.",
          example: "e.g. User needs a faster checkout experience.",
          component: <IdeaAnimation />
      },
      {
          id: 1,
          label: "Design",
          icon: Figma,
          color: "text-purple-500",
          title: "Visual Architecture",
          desc: "Drafting high-fidelity interfaces and user flows.",
          example: "e.g. Designing a 1-click buy button in Figma.",
          component: <DesignAnimation />
      },
      {
          id: 2,
          label: "Build",
          icon: Terminal,
          color: "text-blue-500",
          title: "Engineering",
          desc: "Writing scalable, type-safe code to breathe life into pixels.",
          example: "e.g. Implementing Stripe API with optimistic UI updates.",
          component: <BuildAnimation />
      },
      {
          id: 3,
          label: "Ship",
          icon: CheckCircle,
          color: "text-green-500",
          title: "Deployment",
          desc: "Testing, optimizing, and launching to the global edge.",
          example: "e.g. Deployed to Vercel Edge Network. 99% Lighthouse.",
          component: <ShipAnimation />
      }
  ];

  return (
    <div 
        className="flex flex-col w-full max-w-4xl mx-auto p-0 bg-white rounded-2xl border border-stone-200 shadow-xl overflow-hidden my-12"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
    >
      
      {/* Top Navigation / Progress Bar */}
      <div className="flex border-b border-stone-100 bg-stone-50 overflow-x-auto">
          {stages.map((s, index) => (
              <button
                key={s.id}
                onClick={() => setStep(index)}
                className={`flex-1 flex flex-col items-center justify-center py-4 px-2 min-w-[80px] transition-all duration-300 relative group outline-none ${step === index ? 'bg-white' : 'hover:bg-stone-100'}`}
              >
                  <div className={`mb-2 p-2 rounded-lg transition-all duration-300 ${step === index ? 'bg-stone-900 text-white scale-110 shadow-md' : 'bg-transparent text-stone-400 group-hover:text-stone-600'}`}>
                      <s.icon size={20} />
                  </div>
                  <span className={`text-[10px] font-bold tracking-widest uppercase ${step === index ? 'text-stone-900' : 'text-stone-400'}`}>
                      {s.label}
                  </span>
                  
                  {/* Progress Line Indicator */}
                  {step === index && (
                      <motion.div 
                        layoutId="activeTab"
                        className="absolute bottom-0 left-0 right-0 h-1 bg-nobel-gold" 
                      />
                  )}
              </button>
          ))}
      </div>

      {/* Main Content Area */}
      <div className="grid grid-cols-1 md:grid-cols-2 min-h-[350px]">
          
          {/* Left: Animation Canvas */}
          <div className="p-6 bg-[#F5F4F0] border-b md:border-b-0 md:border-r border-stone-100 flex items-center justify-center">
             <div className="w-full aspect-square md:aspect-auto md:h-64 bg-white rounded-xl shadow-inner border border-stone-200 overflow-hidden relative">
                <AnimatePresence mode="wait">
                    <motion.div
                        key={step}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 1.1 }}
                        transition={{ duration: 0.3 }}
                        className="w-full h-full"
                    >
                        {stages[step].component}
                    </motion.div>
                </AnimatePresence>
             </div>
          </div>

          {/* Right: Context & Details */}
          <div className="p-8 flex flex-col justify-center bg-white relative">
             <AnimatePresence mode="wait">
                 <motion.div
                    key={step}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                 >
                     <div className="flex items-center gap-3 mb-4">
                        <div className={`p-2 rounded-md bg-stone-100 ${stages[step].color}`}>
                            {React.createElement(stages[step].icon, { size: 18 })}
                        </div>
                        <span className="text-xs font-bold text-stone-400 uppercase tracking-wider">Step {step + 1} of 4</span>
                     </div>
                     
                     <h3 className="font-serif text-3xl text-stone-900 mb-4">{stages[step].title}</h3>
                     
                     <p className="text-stone-600 leading-relaxed mb-8">
                         {stages[step].desc}
                     </p>
                     
                     <div className="bg-stone-50 border-l-4 border-stone-300 pl-4 py-3 rounded-r-lg">
                        <span className="block text-xs font-bold text-stone-400 uppercase mb-1">Real World Scenario</span>
                        <p className="font-mono text-sm text-stone-700">{stages[step].example}</p>
                     </div>

                 </motion.div>
             </AnimatePresence>

             {/* Auto-play Timer Indicator */}
             {!isHovered && (
                 <div className="absolute bottom-0 left-0 h-1 bg-stone-100 w-full">
                     <motion.div 
                        key={step} // Reset animation on step change
                        className="h-full bg-stone-200"
                        initial={{ width: "0%" }}
                        animate={{ width: "100%" }}
                        transition={{ duration: 4, ease: "linear" }}
                     />
                 </div>
             )}
          </div>
      </div>

    </div>
  );
};

// --- CLIENT IMPACT CHART (Formerly Performance) ---
export const PerformanceMetricDiagram: React.FC = () => {
    const [view, setView] = useState<'speed' | 'ux' | 'roi'>('speed');
    
    const data = {
        speed: { standard: 45, mine: 98, label: "Lighthouse Score" },
        ux: { standard: 60, mine: 95, label: "User Satisfaction" },
        roi: { standard: 15, mine: 140, label: "Conversion Lift (%)" } 
    };

    const currentData = data[view];
    const maxVal = Math.max(currentData.standard, currentData.mine) * 1.2;
    
    return (
        <div className="flex flex-col md:flex-row gap-8 items-center p-8 bg-stone-900 text-stone-100 rounded-xl my-8 border border-stone-800 shadow-lg">
            <div className="flex-1 min-w-[240px]">
                <h3 className="font-serif text-xl mb-2 text-nobel-gold">Client Outcomes</h3>
                <p className="text-stone-400 text-sm mb-4 leading-relaxed">
                    Aesthetics attract, but performance retains. I obsess over metrics that matter to your business.
                </p>
                <div className="flex gap-2 mt-6">
                    <button onClick={() => setView('speed')} className={`px-3 py-1.5 rounded text-xs font-medium transition-all duration-200 border ${view === 'speed' ? 'bg-nobel-gold text-stone-900 border-nobel-gold' : 'bg-transparent text-stone-400 border-stone-700'}`}>Speed</button>
                    <button onClick={() => setView('ux')} className={`px-3 py-1.5 rounded text-xs font-medium transition-all duration-200 border ${view === 'ux' ? 'bg-nobel-gold text-stone-900 border-nobel-gold' : 'bg-transparent text-stone-400 border-stone-700'}`}>UX</button>
                    <button onClick={() => setView('roi')} className={`px-3 py-1.5 rounded text-xs font-medium transition-all duration-200 border ${view === 'roi' ? 'bg-nobel-gold text-stone-900 border-nobel-gold' : 'bg-transparent text-stone-400 border-stone-700'}`}>ROI</button>
                </div>
                <div className="mt-6 font-mono text-xs text-stone-500 flex items-center gap-2">
                    <BarChart2 size={14} className="text-nobel-gold" /> 
                    <span>{currentData.label}</span>
                </div>
            </div>
            
            <div className="relative w-64 h-72 bg-stone-800/50 rounded-xl border border-stone-700/50 p-6 flex justify-around items-end">
                {/* Background Grid Lines */}
                <div className="absolute inset-0 p-6 flex flex-col justify-between pointer-events-none opacity-10">
                   <div className="w-full h-[1px] bg-stone-400"></div>
                   <div className="w-full h-[1px] bg-stone-400"></div>
                   <div className="w-full h-[1px] bg-stone-400"></div>
                   <div className="w-full h-[1px] bg-stone-400"></div>
                </div>

                {/* Standard Bar */}
                <div className="w-20 flex flex-col justify-end items-center h-full z-10">
                    <div className="flex-1 w-full flex items-end justify-center relative mb-3">
                        <div className="absolute -top-5 w-full text-center text-sm font-mono text-stone-400 font-bold bg-stone-900/90 py-1 px-2 rounded backdrop-blur-sm border border-stone-700/50 shadow-sm">{currentData.standard}</div>
                        <motion.div 
                            className="w-full bg-stone-600 rounded-t-md border-t border-x border-stone-500/30"
                            initial={{ height: 0 }}
                            animate={{ height: `${(currentData.standard / maxVal) * 100}%` }}
                            transition={{ type: "spring", stiffness: 80, damping: 15 }}
                        />
                    </div>
                    <div className="h-6 flex items-center text-xs font-bold text-stone-500 uppercase tracking-wider">Avg</div>
                </div>

                {/* My Work Bar */}
                <div className="w-20 flex flex-col justify-end items-center h-full z-10">
                     <div className="flex-1 w-full flex items-end justify-center relative mb-3">
                        <div className="absolute -top-5 w-full text-center text-sm font-mono text-nobel-gold font-bold bg-stone-900/90 py-1 px-2 rounded backdrop-blur-sm border border-nobel-gold/30 shadow-sm">{currentData.mine}</div>
                        <motion.div 
                            className="w-full bg-nobel-gold rounded-t-md shadow-[0_0_20px_rgba(197,160,89,0.25)] relative overflow-hidden"
                            initial={{ height: 0 }}
                            animate={{ height: Math.max(1, (currentData.mine / maxVal) * 100) + '%' }}
                            transition={{ type: "spring", stiffness: 80, damping: 15, delay: 0.1 }}
                        >
                           {/* Shine effect */}
                           <div className="absolute inset-0 bg-gradient-to-tr from-transparent to-white/20"></div>
                        </motion.div>
                    </div>
                     <div className="h-6 flex items-center text-xs font-bold text-nobel-gold uppercase tracking-wider">Sumit</div>
                </div>
            </div>
        </div>
    )
}
